from __future__ import annotations


class ColumnNotFoundError(Exception): ...


class InvalidOperationError(Exception): ...
